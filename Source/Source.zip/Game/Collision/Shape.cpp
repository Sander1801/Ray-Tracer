#include "Collision/Shape.h"
#include "Collision/Ray.h"
#include "Collision/Contact.h"

Shape::Shape()
{
}

Shape::~Shape()
{
}

void Shape::Translate(const vec3 & a_v3Translation)
{
	m_m4Model = m_m4Model.translate(a_v3Translation);
}

const mat4 & Shape::GetModelMatrix() const
{
	return m_m4Model;
}
