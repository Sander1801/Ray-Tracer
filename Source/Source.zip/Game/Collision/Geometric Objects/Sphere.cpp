#include "Collision/Geometric Objects/Sphere.h"

#include <iostream>

Sphere::Sphere()
{
}

Sphere::~Sphere()
{
}

/*
	Analytic solution of ray vs sphere intersection
	@param: a_Ray = the ray.
	@contact: a_Contact = intersection information. Sets the point of intersection, normal and t value.
*/
bool Sphere::Collides(Ray const & a_Ray, Contact & a_Contact) const
{
	vec3 v3SpherePosition = m_v3Center; // Temporary line....

	float t1; float t2;

	vec3 v3Temp = a_Ray.GetOrigin() - v3SpherePosition;

	float a = a_Ray.GetDirection().dot(a_Ray.GetDirection());
	float b = a_Ray.GetDirection().dot(v3Temp) * 2.f;
	float c = v3Temp.dot(v3Temp) - m_fRadius * m_fRadius;
	float fDiscriminant = b * b - 4.f * a * c;

	// No intersection.
	if (fDiscriminant < 0.f) return false;

	if (fDiscriminant == 0) {
		a_Contact.m_fT = -0.5f * b / a;
	}
	else {
		float q = (b > 0.f) ?
				-0.5f * (b + sqrtf(fDiscriminant)) :
				-0.5f * (b - sqrtf(fDiscriminant));
		t1 = q / a;
		t2 = c / q;

		if (t1 > t2) {
			a_Contact.m_fT = t2;
		}
	}
	
	a_Contact.m_v3Point = a_Ray.GetOrigin() + a_Ray.GetDirection() * a_Contact.m_fT;
	a_Contact.m_v3Normal = a_Contact.m_v3Point - v3SpherePosition;
	a_Contact.m_v3Normal = a_Contact.m_v3Normal.normalize();
	 
	return true; 
}

void Sphere::SetRadius(const float a_fRadius)
{
	m_fRadius = a_fRadius;
}

void Sphere::SetCenter(const vec3 & a_v3Center)
{
	m_v3Center = a_v3Center;
}


/*

	float 		t;
	vec3		temp = a_Ray.GetOrigin() - m_v3Center;
	float 		a = a_Ray.GetDirection().dot(a_Ray.GetDirection());
	float 		b = temp.dot(a_Ray.GetDirection()) * 2.f;
	float 		c = temp.dot(temp) - m_fRadius * m_fRadius;
	float 		disc = b * b - 4.0f * a * c;

	if (disc < 0.0)
		return(false);
	else {
		double e = sqrt(disc);
		double denom = 2.0f * a;
		t = static_cast<float>((-b - e) / denom);    // smaller root

		float kEpsilon = 0.001f;

		if (t > kEpsilon) {
			a_Contact.m_fT = t;
			a_Contact.m_v3Normal = (temp + a_Ray.GetDirection() * t) / m_fRadius;
			a_Contact.m_v3Point = a_Ray.GetOrigin() + a_Ray.GetDirection() * t;
			return (true);
		}

		t = static_cast<float>((-b + e) / denom);    // larger root

		if (t > kEpsilon) {
			a_Contact.m_fT = t;
			a_Contact.m_v3Normal = (temp + a_Ray.GetDirection() * t) / m_fRadius;
			a_Contact.m_v3Point = a_Ray.GetOrigin() + a_Ray.GetDirection() * t;
			return (true);
		}
	}

	return (false);

*/