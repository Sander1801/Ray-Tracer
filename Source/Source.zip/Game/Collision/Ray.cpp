#include "Collision/Ray.h"

Ray::Ray(vec3 a_v3Origin, vec3 a_v3Direction, mat4 a_m4Model) :
	m_v3Origin(a_v3Origin),
	m_v3Direction(a_v3Direction),
	m_m4Model(a_m4Model)
{
}

Ray::~Ray()
{
}

void Ray::SetOrigin(const vec3 & a_v3Origin)
{
	m_v3Origin = a_v3Origin;
}

void Ray::SetDirection(const vec3 & a_v3Direction)
{
	m_v3Direction = a_v3Direction;
}

const vec3 & Ray::GetOrigin() const
{
	return m_v3Origin;
}

const vec3 & Ray::GetDirection() const
{
	return m_v3Direction;
}

const mat4 & Ray::GetModelMatrix() const
{
	return m_m4Model;
}
