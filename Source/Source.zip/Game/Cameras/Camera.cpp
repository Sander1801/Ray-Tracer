#include "Cameras/Camera.h"
#include "Collision/Ray.h"
#include "Utilities/Dimension.h"
#include "World.h"

Camera::Camera(Dimension* a_viewDimension, World* a_World) :
	m_viewDimension(a_viewDimension),
	m_World(a_World)
{
}

Camera::~Camera()
{
}

void Camera::SetLookAt(const vec3 & a_Eye, const vec3 & a_Center, const vec3 & a_Up)
{
	m_m4View = m_m4View.lookat(a_Eye, a_Center, a_Up);

	m_v3Target = a_Center;
}

void Camera::SetPerspectiveProjection(float a_FovY, float a_AspectRatio, float a_Near, float a_Far)
{
	m_m4Projection = m_m4Projection.projection(a_FovY, a_AspectRatio, a_Near, a_Far);
}

const mat4 & Camera::GetViewMatrix() const
{
	return m_m4View;
}

const mat4 & Camera::GetProjectionMatrix() const
{
	return m_m4Projection;
}

const Dimension & Camera::GetViewSize() const
{
	return *m_viewDimension;
}

const Ray Camera::GetCameraRay(int iPixelX, int iPixelY) const
{
	// Get the screen size
	int iScreenWidth;
	int iScreenHeight;
	m_World->GetScreenSize(iScreenWidth, iScreenHeight);

	// Ratio of the screen and camera view size
	int iRatioX = iScreenWidth / m_viewDimension->m_iWidth;
	int iRatioY = iScreenHeight / m_viewDimension->m_iHeight;

	// Calculate the ray position of the screen.
	float fPositionX = (iPixelX - (iScreenWidth / 2 + m_v3Target.m_X)) * iRatioX;
	float fPositionY = (iPixelY - (iScreenHeight / 2 + m_v3Target.m_Y)) * iRatioY;

	mat4 m4Model = mat4::translate(vec3(fPositionX, fPositionY, 100.f));
	vec3 v3Origin(0.f, 0.f, 0.f);
	vec3 v3Direction(0.f, 0.f, 1.f);

	return Ray(v3Origin, v3Direction, m4Model);
}
