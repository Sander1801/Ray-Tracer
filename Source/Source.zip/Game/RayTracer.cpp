#include "RayTracer.h"
#include "Scenes/Scene.h"
#include "Utilities/Dimension.h"
#include "Collision/Contact.h"
#include "Collision/Geometric Objects/Sphere.h"

#include <iostream>

RayTracer::RayTracer(Scene* a_Scene, sf::RenderWindow & a_RenderWindow) :
	m_Scene(a_Scene),
	m_RenderWindow(a_RenderWindow)
{
	// Get the camera dimension
	const Dimension& viewDimension = m_Scene->GetCamera().GetViewSize();

	// Setup SFML image
	m_sfImage.create(viewDimension.m_iWidth, viewDimension.m_iHeight, sf::Color(20, 120, 0)); // Green background
	m_sfTexture.loadFromImage(m_sfImage);
	m_sfSprite.setTexture(m_sfTexture);
	m_sfSprite.setPosition(-(viewDimension.m_iWidth / 2.f), -(viewDimension.m_iHeight / 2.f));
}

RayTracer::~RayTracer()
{
}

void RayTracer::Render()
{
	// Get the camera dimension
	const Dimension& viewDimension = m_Scene->GetCamera().GetViewSize();

	// Get the shapes
	const std::vector<Shape*>& shapes = m_Scene->GetShapes();

	// Intersection information
	Contact contact;

	// TESTING -  Set sphere position
	mat4 mvp = m_Scene->GetCamera().GetProjectionMatrix() * m_Scene->GetCamera().GetViewMatrix() * shapes[0]->GetModelMatrix();
	vec3 pos = mvp * vec3(0.f, 0.f, 0.f);
	Sphere* sphereTest = static_cast<Sphere*>(shapes[0]); // This is for testing.
	sphereTest->SetCenter(pos);

	for (int r = 0; r < viewDimension.m_iHeight; r++) {
		for (int c = 0; c < viewDimension.m_iWidth; c++) {
			// Get the ray
			Ray ray = m_Scene->GetCamera().GetCameraRay(r, c);

			// CHANGE THIS - Set the screen position from the center
			mat4 mvpRay = m_Scene->GetCamera().GetProjectionMatrix() * m_Scene->GetCamera().GetViewMatrix() * ray.GetModelMatrix();
			ray.SetOrigin(mvpRay * ray.GetOrigin());
			vec3 rayPos = ray.GetOrigin();

			if (sphereTest->Collides(ray, contact)) {
				sf::Color testColor;
				vec3 testeeen = ray.GetOrigin() * contact.m_fT + ray.GetDirection();

				testColor.r = 4 * static_cast<sf::Uint8>(testeeen.m_X);
				testColor.g = 2 * static_cast<sf::Uint8>(testeeen.m_Y);
				testColor.b = 2 * static_cast<sf::Uint8>(testeeen.m_Z);
				testColor.a = 255;

				m_sfImage.setPixel(static_cast<int>(rayPos.m_X) + (m_Scene->GetCamera().GetViewSize().m_iWidth / 2), static_cast<int>(rayPos.m_Y) + (m_Scene->GetCamera().GetViewSize().m_iHeight / 2), testColor);
			}
		}
	}

	m_sfTexture.loadFromImage(m_sfImage);
	m_sfSprite.setTexture(m_sfTexture);
}

void RayTracer::OnUpdate()
{
	m_RenderWindow.draw(m_sfSprite);
}