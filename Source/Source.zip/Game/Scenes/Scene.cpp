#include "RayTracer.h"

#include <iostream>

RayTracer::RayTracer()
{
}

RayTracer::~RayTracer()
{
}
