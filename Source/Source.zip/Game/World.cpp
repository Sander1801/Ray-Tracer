#include "World.h"
#include "Utilities/Dimension.h"
#include "Engine/Math/Matrix.h"
#include "Engine/Math/Vector.h"
// Standard C++
#include <iostream>

World::World(Dimension& a_RWDimension, sf::RenderWindow & a_RenderWindow) :
	m_RWDimension(a_RWDimension),
	m_RenderWindow(a_RenderWindow)
{
	// Setup scene
	m_Scene = new Scene(this);

	// Setup ray tracer
	m_RayTracer = new RayTracer(m_Scene, m_RenderWindow);
	m_RayTracer->Render();
}

World::~World()
{
}

void World::OnUpdate(float a_fDeltaTime)
{
	m_RayTracer->OnUpdate();

	// Do not need it at the moment. Need to use it otherwise we get a warning.....................................
	a_fDeltaTime = a_fDeltaTime;
}

void World::GetScreenSize(int & m_iScreenWidth, int & m_iScreenHeight) const
{
	m_iScreenWidth = m_RWDimension.m_iWidth;
	m_iScreenHeight = m_RWDimension.m_iHeight;
}
