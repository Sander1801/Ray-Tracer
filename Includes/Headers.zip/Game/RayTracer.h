#ifndef __RayTracer_H_
#define __RayTracer_H_

#include "Engine/Engine.h"
// SFML 
#include <SFML/Graphics.hpp>

class World;
class Scene;

class RayTracer : public Engine
{
public:
	RayTracer(Scene* a_Scene, sf::RenderWindow& a_RenderWindow);
	~RayTracer();

	void Render();
	void OnUpdate(); // temporary..

private:
	Scene* m_Scene;
	sf::RenderWindow& m_RenderWindow;

	sf::Texture m_sfTexture;
	sf::Image m_sfImage;
	sf::Sprite m_sfSprite;
};

#endif // __RayTracer_H_