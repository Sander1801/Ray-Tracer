#ifndef __World_H_
#define __World_H_

#include "Scenes/Scene.h"
#include "RayTracer.h"
// SFML 
#include <SFML/Graphics.hpp>

struct Dimension;

class World
{
public:
	World(Dimension& a_RWDimension, sf::RenderWindow& a_RenderWindow);
	~World();

	void OnUpdate(float a_fDeltaTime);

	void GetScreenSize(int & m_iScreenWidth, int& m_iScreenHeight) const;

private:
	Dimension& m_RWDimension;
	sf::RenderWindow& m_RenderWindow;
	Scene* m_Scene;
	RayTracer* m_RayTracer;
};

#endif // __World_H_