struct Dimension
{
	int m_iWidth;
	int m_iHeight;
};