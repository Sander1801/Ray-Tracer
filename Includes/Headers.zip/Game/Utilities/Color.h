struct Color
{
	unsigned char R;
	unsigned char G;
	unsigned char B;
};