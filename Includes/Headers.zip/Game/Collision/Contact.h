#ifndef __Contact_H_
#define __Contact_H_

#include "Engine/Math/Vector.h"

struct Contact
{
	float m_fT;
	vec3 m_v3Normal;
	vec3 m_v3Point;
};

#endif // __Contact_H_