#ifndef __Sphere_H_
#define __Sphere_H_

#include "Collision/Shape.h"

class Sphere : public Shape
{
public:
	Sphere();
	~Sphere();

	virtual bool Collides(Ray const& a_Ray, Contact& a_Contact) const;

	void SetRadius(const float a_fRadius);
	void SetCenter(const vec3 &a_v3Center);

private:
	float m_fRadius;
	vec3 m_v3Center;
};

#endif // __Sphere_H_