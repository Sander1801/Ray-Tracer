#ifndef __Shape_H_
#define __Shape_H_

#include "Contact.h"
#include "Ray.h"
#include "Engine/Math/Vector.h"
#include "Engine/Math/Matrix.h"

// Standard C++
#include <math.h>

class Shape
{
public:
	Shape();
	~Shape();

	virtual bool Collides(Ray const& a_Ray, Contact& a_Contact) const = 0;

	void Translate(const vec3 &a_v3Translation);

	const mat4& GetModelMatrix() const;
	
private:
	mat4 m_m4Model;
};

#endif // __Shape_H_