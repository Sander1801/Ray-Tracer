#include "Scene.h"
#include "World.h"
#include "Utilities/Dimension.h"
#include "Collision/Shape.h"
#include "Collision/Geometric Objects/Sphere.h"

Scene::Scene(World* a_World) : m_World(a_World)
{
	// Setup camera dimension
	Dimension* cameraDimension = new Dimension();
	cameraDimension->m_iWidth = 1000;
	cameraDimension->m_iHeight = 750;

	// Setup camera
	m_Camera = new Camera(cameraDimension, a_World);
	m_Camera->SetLookAt(vec3(0.f, 0.f, 1.f), vec3(0, 0, 0));
	m_Camera->SetPerspectiveProjection(1.5708f, 4.f / 3.f, 0.1f, 100.0f);

	// Setup shapes
	CreateShapes();

	// Setup lightning
}

Scene::~Scene()
{
}

void Scene::CreateShapes()
{
	Sphere* sphere1 = new Sphere();
	sphere1->SetRadius(100.f);
	sphere1->SetCenter(vec3(0.f, 0.f, 0.f));
	sphere1->Translate(vec3(0.f, 0.f, 0.f));

	m_Shapes.push_back(sphere1);
}

const std::vector<Shape*> & Scene::GetShapes() const
{
	return m_Shapes;
}

const Camera & Scene::GetCamera() const
{
	return *m_Camera;
}
