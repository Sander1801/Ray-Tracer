#ifndef __Scene_H_
#define __Scene_H_

#include "Cameras/Camera.h"
#include "Collision/Shape.h"
// Standard C++ 
#include <vector>

class World;

class Scene
{
public:
	Scene(World* a_World);
	~Scene();

	void CreateShapes();

	const std::vector<Shape*>& GetShapes() const;
	const Camera& GetCamera() const;

private:
	World* m_World;
	Camera* m_Camera;
	std::vector<Shape*> m_Shapes;
};

#endif // __Scene_H_