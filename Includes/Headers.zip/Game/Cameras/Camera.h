#ifndef __Camera_H_
#define __Camera_H_

#include "Engine/Math/Vector.h"
#include "Engine/Math/Matrix.h"

struct Dimension;

class Ray;
class World;

class Camera
{
public:
	Camera(Dimension* a_viewDimension, World* a_World);
	~Camera();

	void SetLookAt(const vec3 &a_Eye, const vec3 &a_Center, const vec3 &a_Up = vec3(0, 1, 0));
	void SetPerspectiveProjection(float a_FovY, float a_AspectRatio, float a_Near, float a_Far);

	const mat4& GetViewMatrix() const;
	const mat4& GetProjectionMatrix() const;
	const Dimension& GetViewSize() const;

	const Ray GetCameraRay(int iPixelX, int iPixelY) const;

private:
	World* m_World;
	Dimension* m_viewDimension;

	vec3 m_v3Target;
	mat4 m_m4View;
	mat4 m_m4Projection;
};

#endif // __Camera_H_